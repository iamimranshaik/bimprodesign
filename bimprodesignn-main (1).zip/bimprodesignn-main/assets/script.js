(function () {
  'use strict';

  var toggle = document.querySelector('.nav-toggle-btn');
  var links = document.querySelector('.nav-links');
  var dropdown = document.querySelector('.has-dropdown');

  if (toggle && links) {
    toggle.addEventListener('click', function () {
      var open = links.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', String(open));
    });
  }

  if (dropdown) {
    var parentLink = dropdown.querySelector(':scope > a');
    if (parentLink) {
      parentLink.addEventListener('click', function (event) {
        if (window.innerWidth <= 850) {
          event.preventDefault();
          dropdown.classList.toggle('is-open');
        }
      });
    }
  }

  document.addEventListener('click', function (event) {
    if (links && toggle && !links.contains(event.target) && !toggle.contains(event.target)) {
      links.classList.remove('is-open');
    }
  });
})();
